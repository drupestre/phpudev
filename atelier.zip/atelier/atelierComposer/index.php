<?php
require './vendor/autoload.php';

use Symfony\Component\Yaml\Yaml;

$value = Yaml::parse("foo: bar");
var_dump($value);