<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class HomeController extends AbstractController
{
	public function index() {
		
		
		
		return $this->render('home.html.twig');
		
		
		
		//return new Response('Hello world');
		
		
		/*
		return new JsonResponse([
			'success' => true,
			'message' => 'hello wordl',
		]);
		*/
	}
}